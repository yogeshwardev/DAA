"""Q4 - Conventional vs Strassen matrix multiplication (pure Python lists), instrumented."""
import random, json, time, statistics

class C:
    def __init__(self): self.mul = 0; self.add = 0

def conventional(A, B, c):
    n, m, p = len(A), len(B), len(B[0])
    R = [[0] * p for _ in range(n)]
    for i in range(n):
        Ai, Ri = A[i], R[i]
        for k in range(m):
            a = Ai[k]; Bk = B[k]
            for j in range(p):
                Ri[j] += a * Bk[j]
    c.mul += n * m * p; c.add += n * m * p
    return R

def madd(X, Y, c, s=1):
    n = len(X); c.add += n * n
    return [[X[i][j] + s * Y[i][j] for j in range(n)] for i in range(n)]

def split(M):
    h = len(M) // 2
    return ([r[:h] for r in M[:h]], [r[h:] for r in M[:h]],
            [r[:h] for r in M[h:]], [r[h:] for r in M[h:]])

def strassen_sq(A, B, c, leaf):
    n = len(A)
    if n <= leaf:
        return conventional(A, B, c)
    A11, A12, A21, A22 = split(A); B11, B12, B21, B22 = split(B)
    M1 = strassen_sq(madd(A11, A22, c), madd(B11, B22, c), c, leaf)
    M2 = strassen_sq(madd(A21, A22, c), B11, c, leaf)
    M3 = strassen_sq(A11, madd(B12, B22, c, -1), c, leaf)
    M4 = strassen_sq(A22, madd(B21, B11, c, -1), c, leaf)
    M5 = strassen_sq(madd(A11, A12, c), B22, c, leaf)
    M6 = strassen_sq(madd(A21, A11, c, -1), madd(B11, B12, c), c, leaf)
    M7 = strassen_sq(madd(A12, A22, c, -1), madd(B21, B22, c), c, leaf)
    C11 = madd(madd(M1, M4, c), madd(M7, M5, c, -1), c)   # M1+M4-M5+M7
    C12 = madd(M3, M5, c)
    C21 = madd(M2, M4, c)
    C22 = madd(madd(M1, M2, c, -1), madd(M3, M6, c), c)   # M1-M2+M3+M6
    top = [C11[i] + C12[i] for i in range(len(C11))]
    bot = [C21[i] + C22[i] for i in range(len(C21))]
    return top + bot

def strassen(A, B, c, leaf=1):
    n = len(A); p = 1
    while p < n: p *= 2
    if p != n:   # pad with zeros to next power of two
        A = [r + [0] * (p - n) for r in A] + [[0] * p for _ in range(p - n)]
        B = [r + [0] * (p - n) for r in B] + [[0] * p for _ in range(p - n)]
    R = strassen_sq(A, B, c, leaf)
    return [r[:n] for r in R[:n]], p

def rnd(n): return [[random.randint(-9, 9) for _ in range(n)] for _ in range(n)]

def t(f, reps):
    ts = []
    for _ in range(reps):
        s = time.perf_counter(); f(); ts.append(time.perf_counter() - s)
    return statistics.median(ts)

if __name__ == "__main__":
    random.seed(4)
    rows = []
    for n in [2, 4, 8, 16, 32, 64, 100, 128, 129, 256]:
        A, B = rnd(n), rnd(n)
        c0, c1, c2 = C(), C(), C()
        ref = conventional(A, B, c0)
        r1, p = strassen(A, B, c1, 1); r2, _ = strassen(A, B, c2, 32)
        assert r1 == ref and r2 == ref
        reps = 3 if n >= 128 else 5
        tc = t(lambda: conventional(A, B, C()), reps)
        ts1 = t(lambda: strassen(A, B, C(), 1), reps) if n <= 129 else None
        ts32 = t(lambda: strassen(A, B, C(), 32), reps)
        row = dict(n=n, padded_to=p, conv_mul=c0.mul, str_mul_leaf1=c1.mul, str_add_leaf1=c1.add,
                   str_mul_leaf32=c2.mul, str_add_leaf32=c2.add,
                   conv_ms=round(tc * 1000, 2), str1_ms=round(ts1 * 1000, 2) if ts1 else None,
                   str32_ms=round(ts32 * 1000, 2))
        rows.append(row); print(row)
    json.dump(rows, open("results_q4.json", "w"), indent=1)
