"""Q5 - Closest pair: brute force (CO2) vs Divide & Conquer, instrumented."""
import random, math, json, time

class C:
    def __init__(self): self.d = 0; self.strip_pts = 0; self.strip_cmp_max = 0

def dist(p, q, c):
    c.d += 1
    return math.hypot(p[0] - q[0], p[1] - q[1])

def brute(P, c):
    best = (math.inf, None)
    for i in range(len(P)):
        for j in range(i + 1, len(P)):
            d = dist(P[i], P[j], c)
            if d < best[0]: best = (d, (P[i], P[j]))
    return best

def closest_dc(P, c):
    Px = sorted(P)                       # by x
    Py = sorted(P, key=lambda p: p[1])   # by y
    return rec(Px, Py, c)

def rec(Px, Py, c):
    n = len(Px)
    if n <= 3:
        return brute(Px, c)
    mid = n // 2; xm = Px[mid][0]
    Lx, Rx = Px[:mid], Px[mid:]
    left_set = set(Lx)
    Ly = [p for p in Py if p in left_set]; Ry = [p for p in Py if p not in left_set]
    bl = rec(Lx, Ly, c); br = rec(Rx, Ry, c)
    best = bl if bl[0] <= br[0] else br
    d = best[0]
    strip = [p for p in Py if abs(p[0] - xm) < d]     # y-sorted strip
    c.strip_pts += len(strip)
    for i in range(len(strip)):
        k = 0
        for j in range(i + 1, len(strip)):
            if strip[j][1] - strip[i][1] >= d: break       # at most 7 checks
            k += 1
            dd = dist(strip[i], strip[j], c)
            if dd < best[0]: best = (dd, (strip[i], strip[j]))
        c.strip_cmp_max = max(c.strip_cmp_max, k)
    return best

def points(n, kind):
    if kind == "uniform":
        s = set()
        while len(s) < n: s.add((random.uniform(0, 1e6), random.uniform(0, 1e6)))
        return list(s)
    if kind == "clustered":
        s = set()
        while len(s) < n:
            cx, cy = random.choice([(1e5, 1e5), (5e5, 8e5), (9e5, 2e5)])
            s.add((random.gauss(cx, 1e3), random.gauss(cy, 1e3)))
        return list(s)
    if kind == "vertical_line":   # all x nearly equal -> stress the strip
        return [(5e5 + random.uniform(-1e-3, 1e-3), float(i)) for i in range(n)]

if __name__ == "__main__":
    random.seed(5)
    rows = []
    for kind in ["uniform", "clustered", "vertical_line"]:
        for n in [4, 8, 16, 32, 64, 128, 256, 512, 1000, 2000, 4000]:
            P = points(n, kind)
            cb, cd = C(), C()
            t = time.perf_counter(); b = brute(P, cb); tb = time.perf_counter() - t
            t = time.perf_counter(); d = closest_dc(P, cd); td = time.perf_counter() - t
            assert abs(b[0] - d[0]) < 1e-9
            r = dict(kind=kind, n=n, brute_dist=cb.d, dc_dist=cd.d, brute_ms=round(tb * 1000, 3),
                     dc_ms=round(td * 1000, 3), max_strip_checks=cd.strip_cmp_max)
            rows.append(r); print(r)
    json.dump(rows, open("results_q5.json", "w"), indent=1)
