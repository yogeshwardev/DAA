"""Q2 - Merge Sort vs Quick Sort (Lomuto, last-element pivot), instrumented."""
import random, json, sys, time
sys.setrecursionlimit(100000)

class Stats:
    def __init__(self): self.cmp = 0; self.max_depth = 0; self.splits = []

def merge_sort(a, st, depth=1):
    st.max_depth = max(st.max_depth, depth)
    if len(a) <= 1: return a
    mid = len(a) // 2
    if depth <= 3: st.splits.append((depth, mid, len(a) - mid))
    L = merge_sort(a[:mid], st, depth + 1); R = merge_sort(a[mid:], st, depth + 1)
    i = j = 0; out = []
    while i < len(L) and j < len(R):
        st.cmp += 1
        if L[i] <= R[j]: out.append(L[i]); i += 1
        else: out.append(R[j]); j += 1
    out += L[i:]; out += R[j:]
    return out

def partition(a, lo, hi, st):
    pivot = a[hi]; i = lo - 1             # pivot strategy: LAST element (Lomuto)
    for j in range(lo, hi):
        st.cmp += 1
        if a[j] <= pivot:
            i += 1; a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1

def quick_sort(a, lo, hi, st, depth=1):
    st.max_depth = max(st.max_depth, depth)
    if lo >= hi: return
    p = partition(a, lo, hi, st)
    if depth <= 3: st.splits.append((depth, p - lo, hi - p))   # left size, right size
    quick_sort(a, lo, p - 1, st, depth + 1)
    quick_sort(a, p + 1, hi, st, depth + 1)

def balanced_input(n):
    """Builds an array where the LAST element of every subarray is its median,
    so Lomuto last-pivot splits perfectly in half at every level."""
    def build(vals):
        if len(vals) <= 1: return list(vals)
        m = (len(vals) - 1) // 2
        left, piv, right = vals[:m], vals[m], vals[m + 1:]
        L, R = build(left), build(right)
        # Layout [L, X, pivot]: Lomuto leaves L in place, then the final swap moves
        # X[0] to the end, so the right subarray becomes X[1:] + [X[0]].
        # Choosing X = [R[-1]] + R[:-1] makes that equal to R (itself balanced).
        X = [R[-1]] + R[:-1] if R else []
        return L + X + [piv]
    return build(list(range(n)))

def run(n, kind):
    if kind == "sorted": a = list(range(n))
    elif kind == "reverse": a = list(range(n, 0, -1))
    elif kind == "random": a = random.sample(range(n * 10), n)
    elif kind == "balanced": a = balanced_input(n)
    elif kind == "equal": a = [7] * n
    st_q, st_m = Stats(), Stats()
    b = a[:]; t = time.perf_counter(); quick_sort(b, 0, n - 1, st_q); tq = time.perf_counter() - t
    t = time.perf_counter(); c = merge_sort(a[:], st_m); tm = time.perf_counter() - t
    assert b == c == sorted(a)
    return dict(n=n, kind=kind, qs_cmp=st_q.cmp, qs_depth=st_q.max_depth, qs_ms=round(tq * 1000, 2),
                qs_top_splits=st_q.splits[:3], ms_cmp=st_m.cmp, ms_depth=st_m.max_depth,
                ms_ms=round(tm * 1000, 2), ms_top_splits=st_m.splits[:3])

if __name__ == "__main__":
    random.seed(2)
    rows = []
    for n in [255, 1023, 4095]:
        for kind in ["balanced", "random", "sorted", "reverse", "equal"]:
            r = run(n, kind); rows.append(r); print(r)
    json.dump(rows, open("results_q2.json", "w"), indent=1)
