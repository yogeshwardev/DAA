"""Q3 - Schoolbook vs Karatsuba on digit lists (base 10), instrumented.
Both work on digit arrays so the comparison is fair (Python's built-in * is
itself Karatsuba in C and would hide the effect)."""
import random, json, time, statistics

class C:
    def __init__(self): self.mul = 0; self.calls = 0

def to_digits(x):  return [int(d) for d in str(x)[::-1]]   # little-endian
def from_digits(d): return int("".join(map(str, d[::-1]))) if d else 0

def add(a, b):
    out, carry = [], 0
    for i in range(max(len(a), len(b))):
        s = (a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0) + carry
        out.append(s % 10); carry = s // 10
    if carry: out.append(carry)
    return out

def sub(a, b):  # a >= b
    out, borrow = [], 0
    for i in range(len(a)):
        s = a[i] - (b[i] if i < len(b) else 0) - borrow
        if s < 0: s += 10; borrow = 1
        else: borrow = 0
        out.append(s)
    while len(out) > 1 and out[-1] == 0: out.pop()
    return out

def shift(a, k): return [0] * k + a if a != [0] else [0]

def schoolbook(a, b, c):
    res = [0] * (len(a) + len(b))
    for i, x in enumerate(a):
        carry = 0
        for j, y in enumerate(b):
            c.mul += 1
            t = res[i + j] + x * y + carry
            res[i + j] = t % 10; carry = t // 10
        res[i + len(b)] += carry
    while len(res) > 1 and res[-1] == 0: res.pop()
    return res

def karatsuba(a, b, c, base_case=1):
    c.calls += 1
    n = max(len(a), len(b))
    if n <= base_case:
        return schoolbook(a, b, c)
    m = n // 2
    a0, a1 = a[:m] or [0], a[m:] or [0]       # a = a1*10^m + a0
    b0, b1 = b[:m] or [0], b[m:] or [0]
    z0 = karatsuba(a0, b0, c, base_case)                          # low*low
    z2 = karatsuba(a1, b1, c, base_case)                          # high*high
    z1 = karatsuba(add(a0, a1), add(b0, b1), c, base_case)        # (a0+a1)(b0+b1)
    mid = sub(sub(z1, z2), z0)                                    # = a0b1 + a1b0
    return add(add(shift(z2, 2 * m), shift(mid, m)), z0)

def timeit(f, reps=5):
    ts = []
    for _ in range(reps):
        t = time.perf_counter(); f(); ts.append(time.perf_counter() - t)
    return statistics.median(ts)

if __name__ == "__main__":
    random.seed(3)
    rows = []
    for n in [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]:
        x = random.randrange(10 ** (n - 1), 10 ** n); y = random.randrange(10 ** (n - 1), 10 ** n)
        A, B = to_digits(x), to_digits(y)
        c1, c2, c3 = C(), C(), C()
        assert from_digits(schoolbook(A, B, c1)) == x * y
        assert from_digits(karatsuba(A, B, c2, 1)) == x * y
        assert from_digits(karatsuba(A, B, c3, 32)) == x * y
        reps = 5 if n <= 512 else 3
        ts = timeit(lambda: schoolbook(A, B, C()), reps)
        tk = timeit(lambda: karatsuba(A, B, C(), 1), reps)
        th = timeit(lambda: karatsuba(A, B, C(), 32), reps)
        r = dict(n=n, school_mul=c1.mul, kara_mul=c2.mul, kara_calls=c2.calls, n_pow_1585=round(n ** 1.585),
                 school_ms=round(ts * 1000, 3), kara_ms=round(tk * 1000, 3), hybrid32_ms=round(th * 1000, 3),
                 hybrid_mul=c3.mul)
        rows.append(r); print(r)
    json.dump(rows, open("results_q3.json", "w"), indent=1)
