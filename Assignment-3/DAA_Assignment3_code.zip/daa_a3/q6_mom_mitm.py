"""Q6 - Median of Medians vs QuickSelect; Meet-in-the-Middle Subset Sum."""
import random, json, time, bisect, sys
sys.setrecursionlimit(100000)

class C:
    def __init__(self): self.cmp = 0; self.depth = 0; self.worst_frac = 0.0

# ---------- Selection ----------
def partition3(a, pivot, c):
    L, E, G = [], [], []
    for x in a:
        c.cmp += 1
        if x < pivot: L.append(x)
        elif x > pivot: G.append(x)
        else: E.append(x)
    return L, E, G

def mom_select(a, k, c, d=1):
    """k-th smallest, 0-indexed. Deterministic O(n)."""
    c.depth = max(c.depth, d)
    if len(a) <= 5:
        c.cmp += len(a) * len(a)       # insertion-sort bound, tiny
        return sorted(a)[k]
    groups = [a[i:i + 5] for i in range(0, len(a), 5)]
    meds = []
    for g in groups:
        c.cmp += len(g) * (len(g) - 1) // 2
        meds.append(sorted(g)[len(g) // 2])
    pivot = mom_select(meds, len(meds) // 2, c, d + 1)
    L, E, G = partition3(a, pivot, c)
    if len(a) >= 100: c.worst_frac = max(c.worst_frac, max(len(L), len(G)) / len(a))
    if k < len(L): return mom_select(L, k, c, d + 1)
    if k < len(L) + len(E): return pivot
    return mom_select(G, k - len(L) - len(E), c, d + 1)

def quickselect(a, k, c, rule, d=1):
    while True:
        c.depth = max(c.depth, d)
        if len(a) == 1: return a[0]
        pivot = a[0] if rule == "first" else random.choice(a)
        L, E, G = partition3(a, pivot, c)
        if len(a) >= 100: c.worst_frac = max(c.worst_frac, max(len(L), len(G)) / len(a))
        if k < len(L): a = L
        elif k < len(L) + len(E): return pivot
        else: a, k = G, k - len(L) - len(E)
        d += 1

def selection_experiment():
    rows = []
    for n in [1000, 5000, 20000]:
        for kind in ["random", "sorted"]:
            a = list(range(n))
            if kind == "random": random.shuffle(a)
            k = n - 1 if kind == "sorted" else n // 2      # max of sorted = worst for first-pivot
            res = {}
            for name in ["mom", "qs_first", "qs_random"]:
                c = C(); t = time.perf_counter()
                if name == "mom": v = mom_select(a[:], k, c)
                elif name == "qs_first": v = quickselect(a[:], k, c, "first")
                else:
                    # random pivot: run 20 trials, keep mean and worst
                    cs, ds = [], []
                    for _ in range(20):
                        cc = C(); quickselect(a[:], k, cc, "random"); cs.append(cc.cmp); ds.append(cc.depth)
                        c.worst_frac = max(c.worst_frac, cc.worst_frac)
                    c.cmp = sum(cs) // len(cs); c.worst = max(cs); c.depth = max(ds); v = sorted(a)[k]
                el = time.perf_counter() - t
                assert v == sorted(a)[k]
                res[name] = dict(cmp=c.cmp, cmp_per_n=round(c.cmp / n, 2), depth=c.depth,
                                 worst_split=round(c.worst_frac, 3), ms=round(el * 1000, 2))
                if name == "qs_random": res[name]["worst_of_20"] = c.worst; res[name]["worst_per_n"] = round(c.worst / n, 2)
            rows.append(dict(n=n, kind=kind, k=k, **res)); print(rows[-1])
    return rows

# ---------- Meet in the middle ----------
def all_sums(arr, c):
    sums = [0]
    for x in arr:
        sums = sums + [s + x for s in sums]
    c.gen += len(sums)
    return sums

class M:
    def __init__(self): self.gen = 0; self.probes = 0

def brute_subset(arr, T, m):
    n = len(arr)
    for mask in range(1 << n):
        m.probes += 1
        s = 0
        for i in range(n):
            if mask >> i & 1: s += arr[i]
        if s == T: return True
    return False

def mitm_subset(arr, T, m):
    h = len(arr) // 2
    A = all_sums(arr[:h], m); B = sorted(all_sums(arr[h:], m))
    for s in A:
        m.probes += 1
        j = bisect.bisect_left(B, T - s)
        if j < len(B) and B[j] == T - s: return True, len(A) + len(B)
    return False, len(A) + len(B)

def mitm_experiment():
    rows = []
    for n in [10, 14, 16, 18, 20, 22, 24, 30, 36, 40]:
        arr = [random.randint(1, 10 ** 9) for _ in range(n)]
        T = sum(arr) + 1   # unreachable target -> worst case, full search
        m1, m2 = M(), M()
        t = time.perf_counter(); f2, stored = mitm_subset(arr, T, m2); tm = time.perf_counter() - t
        tb = None
        if n <= 20:
            t = time.perf_counter(); f1 = brute_subset(arr, T, m1); tb = time.perf_counter() - t
            assert f1 == f2
        # also check a reachable target
        sub = random.sample(arr, n // 3); assert mitm_subset(arr, sum(sub), M())[0]
        r = dict(n=n, brute_subsets=2 ** n, mitm_stored=stored, mitm_probes=m2.probes,
                 brute_ms=round(tb * 1000, 1) if tb is not None else None, mitm_ms=round(tm * 1000, 2),
                 mitm_mem_MB=round(stored * 28 / 1e6, 2))
        rows.append(r); print(r)
    return rows

if __name__ == "__main__":
    random.seed(6)
    out = {"selection": selection_experiment(), "mitm": mitm_experiment()}
    json.dump(out, open("results_q6.json", "w"), indent=1)
