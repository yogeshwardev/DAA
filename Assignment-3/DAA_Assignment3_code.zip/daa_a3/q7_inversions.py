"""Q7 - Day-4 design: count inversions (pairs i<j with a[i] > a[j]) by D&C,
compared with the O(n^2) baseline."""
import random, json, time

class C:
    def __init__(self): self.cmp = 0; self.depth = 0

def count_brute(a, c):
    inv = 0
    for i in range(len(a)):
        for j in range(i + 1, len(a)):
            c.cmp += 1
            if a[i] > a[j]: inv += 1
    return inv

def sort_count(a, c, d=1):
    """Returns (sorted copy of a, number of inversions in a)."""
    c.depth = max(c.depth, d)
    n = len(a)
    if n <= 1:
        return a[:], 0
    mid = n // 2
    L, x = sort_count(a[:mid], c, d + 1)
    R, y = sort_count(a[mid:], c, d + 1)
    merged, i, j, z = [], 0, 0, 0
    while i < len(L) and j < len(R):
        c.cmp += 1
        if L[i] <= R[j]:
            merged.append(L[i]); i += 1
        else:                      # R[j] is smaller than every remaining L element
            merged.append(R[j]); j += 1
            z += len(L) - i        # cross inversions counted in one step
    merged += L[i:]; merged += R[j:]
    return merged, x + y + z

if __name__ == "__main__":
    random.seed(7)
    # correctness tests
    tests = {"empty": [], "single": [5], "sorted": [1, 2, 3, 4, 5], "reverse": [5, 4, 3, 2, 1],
             "duplicates": [2, 2, 1, 1], "example": [8, 4, 2, 1], "mixed": [3, 1, 2, 5, 4],
             "negatives": [-1, -5, 3, 0]}
    tres = []
    for name, a in tests.items():
        c1, c2 = C(), C()
        e, got = count_brute(a, c1), sort_count(a, c2)[1]
        assert e == got; tres.append(dict(name=name, input=a, expected=e, got=got))
    for _ in range(500):
        a = [random.randint(0, 20) for _ in range(random.randint(0, 40))]
        assert count_brute(a, C()) == sort_count(a, C())[1]
    print(tres)
    rows = []
    for n in [10, 100, 500, 1000, 2000, 4000, 8000, 100000]:
        a = random.sample(range(10 * n), n)
        cb, cd = C(), C()
        tb = None
        if n <= 8000:
            t = time.perf_counter(); r1 = count_brute(a, cb); tb = time.perf_counter() - t
        t = time.perf_counter(); r2 = sort_count(a, cd)[1]; td = time.perf_counter() - t
        if tb is not None: assert r1 == r2
        rows.append(dict(n=n, inversions=r2, brute_cmp=cb.cmp if tb else n * (n - 1) // 2,
                         dc_cmp=cd.cmp, depth=cd.depth, brute_ms=round(tb * 1000, 2) if tb else None,
                         dc_ms=round(td * 1000, 2)))
        print(rows[-1])
    json.dump({"tests": tres, "rows": rows}, open("results_q7.json", "w"), indent=1)
