"""Q1 - Max/Min (tournament D&C) and Binary Search, instrumented."""
import random, math, json, sys
sys.setrecursionlimit(10000)

# ---------- Part A: Max/Min ----------
class Counter:
    def __init__(self): self.c = 0

def maxmin_dc(a, lo, hi, cnt):
    """Returns (min, max) of a[lo..hi]."""
    if lo == hi:                       # one element: no comparison
        return a[lo], a[lo]
    if hi == lo + 1:                   # two elements: one comparison
        cnt.c += 1
        return (a[lo], a[hi]) if a[lo] < a[hi] else (a[hi], a[lo])
    mid = (lo + hi) // 2
    mn1, mx1 = maxmin_dc(a, lo, mid, cnt)
    mn2, mx2 = maxmin_dc(a, mid + 1, hi, cnt)
    cnt.c += 2                         # combine: compare mins, compare maxes
    return min(mn1, mn2), max(mx1, mx2)

def maxmin_naive(a, cnt):
    mn = mx = a[0]
    for x in a[1:]:
        cnt.c += 1
        if x < mn: mn = x
        cnt.c += 1
        if x > mx: mx = x
    return mn, mx

def predicted_dc(n):
    # exact for the halving recursion above: T(1)=0, T(2)=1, T(n)=T(ceil)+T(floor)+2
    memo = {1: 0, 2: 1}
    def T(k):
        if k not in memo:
            memo[k] = T((k + 1) // 2) + T(k // 2) + 2
        return memo[k]
    return T(n)

def part_a():
    rows = []
    for n in [2, 8, 16, 100, 1000, 1024, 10000, 65536, 100000]:
        for kind in ["random", "sorted", "reverse"]:
            a = list(range(n))
            if kind == "random": random.shuffle(a)
            elif kind == "reverse": a.reverse()
            c1, c2 = Counter(), Counter()
            r1 = maxmin_dc(a, 0, n - 1, c1); r2 = maxmin_naive(a, c2)
            assert r1 == r2 == (min(a), max(a))
            if kind == "random":
                rows.append(dict(n=n, dc_obs=c1.c, dc_pred=predicted_dc(n),
                                 formula=math.ceil(3 * n / 2) - 2, naive=c2.c))
            else:
                assert c1.c == predicted_dc(n)  # input order doesn't matter
    return rows

# ---------- Part B: Binary search ----------
def binary_search(a, x, cnt):
    lo, hi = 0, len(a) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        cnt.c += 1                       # 3-way comparison counted once
        if a[mid] == x: return mid
        elif a[mid] < x: lo = mid + 1    # discard a[lo..mid]
        else: hi = mid - 1               # discard a[mid..hi]
    return -1

def part_b():
    rows = []
    for n in [10, 100, 1000, 10_000, 100_000, 1_000_000]:
        a = list(range(0, 2 * n, 2))      # even numbers -> odd targets are absent
        succ, unsucc, worst_s = [], [], 0
        for _ in range(2000):
            x = a[random.randrange(n)]; c = Counter()
            assert binary_search(a, x, c) != -1; succ.append(c.c)
            y = 2 * random.randrange(n) + 1; c = Counter()
            assert binary_search(a, y, c) == -1; unsucc.append(c.c)
        # special cases
        cases = {}
        for name, x in [("first", a[0]), ("middle", a[(n - 1) // 2]), ("last", a[-1]),
                        ("below_min", -1), ("above_max", 2 * n + 1)]:
            c = Counter(); binary_search(a, x, c); cases[name] = c.c
        rows.append(dict(n=n, succ_avg=round(sum(succ) / len(succ), 2), succ_max=max(succ),
                         unsucc_avg=round(sum(unsucc) / len(unsucc), 2), unsucc_max=max(unsucc),
                         floor_log2_plus1=math.floor(math.log2(n)) + 1, **cases))
    return rows

if __name__ == "__main__":
    random.seed(1)
    out = {"maxmin": part_a(), "bsearch": part_b()}
    json.dump(out, open("results_q1.json", "w"), indent=1)
    for k, v in out.items():
        print(k)
        for r in v: print("  ", r)
